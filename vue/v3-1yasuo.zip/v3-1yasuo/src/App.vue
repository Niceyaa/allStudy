<template>
  <router-view></router-view>
</template>
<style>
html,
body {
  height: 100%;
  margin: 0;
  padding: 0;
}

#app {
  height: 100%;
}

* {
  box-sizing: border-box;
}
</style>


