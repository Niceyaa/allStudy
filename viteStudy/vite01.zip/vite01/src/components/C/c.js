import rectPng from '@assets/rectangle.png'
const img = document.createElement('img')
img.src = rectPng
document.body.appendChild(img)