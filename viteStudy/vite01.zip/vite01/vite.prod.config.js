// 生产环境下的配置
import { defineConfig } from 'vite'

export default defineConfig({})