import _ from 'lodash'
import lodashEs from 'lodash-es'

import './index.css'
import './src/components/A/a.js'
import './src/components/B/b.js'
import './src/components/C/c.js'


console.log('lodash', _)